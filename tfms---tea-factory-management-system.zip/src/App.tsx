/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Activity, 
  Database, 
  Cpu, 
  Layers, 
  Settings, 
  Search, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Thermometer, 
  Droplets, 
  Wind, 
  Zap, 
  Menu, 
  X, 
  ChevronRight, 
  BarChart3, 
  Microscope, 
  Truck, 
  Users, 
  Wrench, 
  DollarSign, 
  PieChart, 
  Share2, 
  Leaf, 
  RefreshCcw, 
  Box, 
  Calendar, 
  ShoppingCart, 
  Globe, 
  FileText 
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  Cell 
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { DOMAINS, generateMicroservices, generateSensorData } from './constants';
import { Microservice, Domain, SensorData, Alert } from './types';

// --- Components ---

const AlertNotification = ({ alert, onDismiss }: { alert: Alert, onDismiss: (id: string) => void }) => (
  <motion.div
    initial={{ opacity: 0, x: 50, scale: 0.9 }}
    animate={{ opacity: 1, x: 0, scale: 1 }}
    exit={{ opacity: 0, x: 20, scale: 0.95 }}
    className={cn(
      "w-80 p-4 rounded-lg border shadow-2xl flex gap-3 relative overflow-hidden group",
      alert.status === 'failed' ? "bg-rose-950/90 border-rose-500/50" : "bg-amber-950/90 border-amber-500/50"
    )}
  >
    <div className={cn(
      "absolute left-0 top-0 bottom-0 w-1",
      alert.status === 'failed' ? "bg-rose-500" : "bg-amber-500"
    )} />
    <div className={cn(
      "p-2 rounded h-fit",
      alert.status === 'failed' ? "bg-rose-500/20 text-rose-500" : "bg-amber-500/20 text-amber-500"
    )}>
      <AlertCircle size={18} />
    </div>
    <div className="flex-1 min-w-0">
      <div className="flex justify-between items-start mb-1">
        <span className="text-[10px] font-mono font-bold uppercase tracking-widest opacity-70">
          {alert.status} • {alert.domain}
        </span>
        <button 
          onClick={() => onDismiss(alert.id)}
          className="text-white/40 hover:text-white transition-colors"
        >
          <X size={14} />
        </button>
      </div>
      <h4 className="text-xs font-mono font-bold text-white truncate mb-1">{alert.serviceName}</h4>
      <p className="text-[10px] font-mono text-white/60 leading-relaxed">{alert.message}</p>
      <div className="mt-2 text-[9px] font-mono text-white/30">{alert.timestamp}</div>
    </div>
  </motion.div>
);

const StatusBadge = ({ status }: { status: Microservice['status'] }) => {
  const styles = {
    healthy: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    degraded: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    failed: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
    starting: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  };
  
  return (
    <span className={cn("px-2 py-0.5 text-[10px] font-mono uppercase tracking-wider border rounded-full", styles[status])}>
      {status}
    </span>
  );
};

const MetricCard = ({ title, value, unit, icon: Icon, trend }: any) => (
  <div className="bg-[#1a1a1a] border border-[#333] p-4 rounded-lg flex flex-col gap-2">
    <div className="flex justify-between items-start">
      <span className="text-[10px] font-mono text-[#888] uppercase tracking-widest">{title}</span>
      <Icon size={14} className="text-[#666]" />
    </div>
    <div className="flex items-baseline gap-1">
      <span className="text-2xl font-mono font-medium text-white">{value}</span>
      <span className="text-[10px] font-mono text-[#666]">{unit}</span>
    </div>
    {trend && (
      <div className={cn("text-[10px] font-mono", trend > 0 ? "text-emerald-500" : "text-rose-500")}>
        {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}% vs last hr
      </div>
    )}
  </div>
);

const DomainIcon = ({ domain, size = 16, className }: { domain: Domain, size?: number, className?: string }) => {
  switch (domain) {
    case 'Agriculture': return <Leaf size={size} className={className} />;
    case 'Processing': return <RefreshCcw size={size} className={className} />;
    case 'QA': return <Microscope size={size} className={className} />;
    case 'Inventory': return <Box size={size} className={className} />;
    case 'Planning': return <Calendar size={size} className={className} />;
    case 'SupplyChain': return <Truck size={size} className={className} />;
    case 'Sales': return <ShoppingCart size={size} className={className} />;
    case 'HR': return <Users size={size} className={className} />;
    case 'Maintenance': return <Wrench size={size} className={className} />;
    case 'Finance': return <DollarSign size={size} className={className} />;
    case 'Analytics': return <PieChart size={size} className={className} />;
    case 'Integration': return <Globe size={size} className={className} />;
    default: return <Layers size={size} className={className} />;
  }
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState<Domain | 'Overview' | 'Registry'>('Overview');
  const [services, setServices] = useState<Microservice[]>([]);
  const [sensorData, setSensorData] = useState<SensorData[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  useEffect(() => {
    setServices(generateMicroservices(1000));
    setSensorData(generateSensorData(20));

    const dataInterval = setInterval(() => {
      setSensorData(prev => {
        const newData = generateSensorData(1)[0];
        return [...prev.slice(1), newData];
      });
    }, 5000);

    // Alert Simulation
    const alertInterval = setInterval(() => {
      if (Math.random() > 0.7) {
        const randomService = services[Math.floor(Math.random() * services.length)];
        if (randomService) {
          const newAlert: Alert = {
            id: Math.random().toString(36).substr(2, 9),
            serviceId: randomService.id,
            serviceName: randomService.name,
            domain: randomService.domain,
            status: Math.random() > 0.5 ? 'failed' : 'degraded',
            timestamp: new Date().toLocaleTimeString(),
            message: `Critical ${Math.random() > 0.5 ? 'latency spike' : 'resource exhaustion'} detected in ${randomService.name}.`
          };
          setAlerts(prev => [newAlert, ...prev].slice(0, 5));
          
          // Update service status in registry
          setServices(prev => prev.map(s => 
            s.id === randomService.id ? { ...s, status: newAlert.status } : s
          ));
        }
      }
    }, 8000);

    return () => {
      clearInterval(dataInterval);
      clearInterval(alertInterval);
    };
  }, [services.length]);

  const dismissAlert = (id: string) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  };

  const filteredServices = useMemo(() => {
    return services.filter(s => 
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.language.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [services, searchQuery]);

  const stats = useMemo(() => {
    const healthy = services.filter(s => s.status === 'healthy').length;
    const failed = services.filter(s => s.status === 'failed').length;
    const degraded = services.filter(s => s.status === 'degraded').length;
    return { healthy, failed, degraded, total: services.length };
  }, [services]);

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard title="System Health" value={`${((stats.healthy / stats.total) * 100).toFixed(1)}`} unit="%" icon={Activity} trend={0.2} />
        <MetricCard title="Total Services" value={stats.total} unit="SVC" icon={Layers} />
        <MetricCard title="Active Errors" value={stats.failed} unit="ERR" icon={AlertCircle} trend={-5} />
        <MetricCard title="Throughput" value="1.2" unit="M/s" icon={Zap} trend={12} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#1a1a1a] border border-[#333] p-6 rounded-lg">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-mono uppercase tracking-widest text-[#888]">Process Real-time Telemetry</h3>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-[10px] font-mono text-[#666]">TEMP</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <span className="text-[10px] font-mono text-[#666]">HUM</span>
              </div>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sensorData}>
                <defs>
                  <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorHum" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                <XAxis dataKey="timestamp" stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333', fontSize: '10px', fontFamily: 'monospace' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="temperature" stroke="#10b981" fillOpacity={1} fill="url(#colorTemp)" />
                <Area type="monotone" dataKey="humidity" stroke="#3b82f6" fillOpacity={1} fill="url(#colorHum)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#333] p-6 rounded-lg">
          <h3 className="text-sm font-mono uppercase tracking-widest text-[#888] mb-6">Domain Distribution</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={DOMAINS.map(d => ({ name: d, count: services.filter(s => s.domain === d).length }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                <XAxis dataKey="name" stroke="#666" fontSize={8} tickLine={false} axisLine={false} />
                <YAxis stroke="#666" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  cursor={{ fill: '#333' }}
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333', fontSize: '10px', fontFamily: 'monospace' }}
                />
                <Bar dataKey="count" fill="#444">
                  {DOMAINS.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#555' : '#666'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-[#1a1a1a] border border-[#333] rounded-lg overflow-hidden">
        <div className="p-4 border-bottom border-[#333] flex justify-between items-center bg-rose-500/5">
          <div className="flex items-center gap-2">
            <AlertCircle size={16} className="text-rose-500" />
            <h3 className="text-sm font-mono uppercase tracking-widest text-rose-500">Live Incident Feed</h3>
          </div>
          <span className="text-[10px] font-mono text-rose-500/50 animate-pulse">REAL-TIME STREAMING</span>
        </div>
        <div className="divide-y divide-[#333]">
          {alerts.length > 0 ? (
            alerts.map(alert => (
              <div key={alert.id} className="p-4 flex items-center justify-between hover:bg-[#222] transition-colors">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-8 h-8 rounded flex items-center justify-center",
                    alert.status === 'failed' ? "bg-rose-500/10 text-rose-500" : "bg-amber-500/10 text-amber-500"
                  )}>
                    <AlertCircle size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-mono text-white">{alert.serviceName}</div>
                    <div className="text-[10px] font-mono text-[#666]">{alert.message}</div>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <div className="text-[10px] font-mono text-[#666] uppercase tracking-widest">Time</div>
                    <div className="text-xs font-mono text-white">{alert.timestamp}</div>
                  </div>
                  <StatusBadge status={alert.status} />
                </div>
              </div>
            ))
          ) : (
            <div className="p-12 text-center text-[#444] font-mono text-xs italic">
              No critical incidents detected in the last 24 hours.
            </div>
          )}
        </div>
      </div>

      <div className="bg-[#1a1a1a] border border-[#333] rounded-lg overflow-hidden">
        <div className="p-4 border-bottom border-[#333] flex justify-between items-center">
          <h3 className="text-sm font-mono uppercase tracking-widest text-[#888]">Service Registry Snapshot</h3>
          <span className="text-[10px] font-mono text-[#444]">TOP 5 FAILURES</span>
        </div>
        <div className="divide-y divide-[#333]">
          {services.filter(s => s.status === 'failed').slice(0, 5).map(s => (
            <div key={s.id} className="p-4 flex items-center justify-between hover:bg-[#222] transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-8 h-8 rounded bg-rose-500/10 flex items-center justify-center text-rose-500">
                  <AlertCircle size={16} />
                </div>
                <div>
                  <div className="text-xs font-mono text-white">{s.name}</div>
                  <div className="text-[10px] font-mono text-[#666]">{s.domain} • {s.language}</div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <div className="text-[10px] font-mono text-[#666] uppercase tracking-widest">Memory</div>
                  <div className="text-xs font-mono text-white">{s.memory} MB</div>
                </div>
                <StatusBadge status={s.status} />
                <button className="p-2 text-[#666] hover:text-white transition-colors">
                  <ChevronRight size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderRegistry = () => (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-[#1a1a1a] border border-[#333] p-4 rounded-lg">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#666]" size={16} />
          <input 
            type="text" 
            placeholder="Search 1000+ microservices..." 
            className="w-full bg-[#0a0a0a] border border-[#333] rounded-md py-2 pl-10 pr-4 text-xs font-mono text-white focus:outline-none focus:border-emerald-500/50 transition-colors"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <button className="px-3 py-1.5 bg-[#0a0a0a] border border-[#333] rounded text-[10px] font-mono text-[#888] hover:text-white transition-colors">ALL</button>
          <button className="px-3 py-1.5 bg-[#0a0a0a] border border-[#333] rounded text-[10px] font-mono text-[#888] hover:text-white transition-colors">HEALTHY</button>
          <button className="px-3 py-1.5 bg-[#0a0a0a] border border-[#333] rounded text-[10px] font-mono text-[#888] hover:text-white transition-colors">FAILED</button>
        </div>
      </div>

      <div className="bg-[#1a1a1a] border border-[#333] rounded-lg overflow-hidden">
        <div className="grid grid-cols-12 gap-4 p-4 border-b border-[#333] text-[10px] font-mono uppercase tracking-widest text-[#666]">
          <div className="col-span-4">Service Name</div>
          <div className="col-span-2">Domain</div>
          <div className="col-span-2">Language</div>
          <div className="col-span-2">Uptime</div>
          <div className="col-span-2">Status</div>
        </div>
        <div className="max-h-[600px] overflow-y-auto divide-y divide-[#333]">
          {filteredServices.slice(0, 100).map(s => (
            <div key={s.id} className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-[#222] transition-colors cursor-pointer group">
              <div className="col-span-4 flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-[#333] group-hover:bg-emerald-500 transition-colors" />
                <span className="text-xs font-mono text-white">{s.name}</span>
              </div>
              <div className="col-span-2 flex items-center gap-2">
                <DomainIcon domain={s.domain as Domain} size={12} className="text-[#666]" />
                <span className="text-[10px] font-mono text-[#888]">{s.domain}</span>
              </div>
              <div className="col-span-2">
                <span className="text-[10px] font-mono text-[#888]">{s.language}</span>
              </div>
              <div className="col-span-2">
                <span className="text-[10px] font-mono text-[#888]">{s.uptime}</span>
              </div>
              <div className="col-span-2">
                <StatusBadge status={s.status} />
              </div>
            </div>
          ))}
          {filteredServices.length === 0 && (
            <div className="p-12 text-center text-[#666] font-mono text-xs">
              No services matching "{searchQuery}"
            </div>
          )}
        </div>
        <div className="p-4 bg-[#0a0a0a] border-t border-[#333] flex justify-between items-center">
          <span className="text-[10px] font-mono text-[#666]">Showing {Math.min(filteredServices.length, 100)} of {filteredServices.length} results</span>
          <div className="flex gap-2">
            <button className="p-1 text-[#666] hover:text-white disabled:opacity-30" disabled>PREV</button>
            <button className="p-1 text-[#666] hover:text-white">NEXT</button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex font-sans selection:bg-emerald-500/30">
      {/* Sidebar */}
      <aside className={cn(
        "bg-[#111] border-r border-[#333] transition-all duration-300 flex flex-col z-50",
        isSidebarOpen ? "w-64" : "w-16"
      )}>
        <div className="p-4 border-b border-[#333] flex items-center justify-between">
          {isSidebarOpen && (
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-emerald-500 rounded flex items-center justify-center text-black font-bold text-xs">T</div>
              <span className="font-mono text-xs font-bold tracking-tighter">TFMS v4.2</span>
            </div>
          )}
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-1 text-[#666] hover:text-white transition-colors">
            {isSidebarOpen ? <X size={16} /> : <Menu size={16} />}
          </button>
        </div>

        <nav className="flex-1 py-4 overflow-y-auto">
          <div className="px-4 mb-4">
            <div className={cn("text-[10px] font-mono uppercase tracking-widest text-[#444] mb-2", !isSidebarOpen && "hidden")}>Main</div>
            <button 
              onClick={() => setActiveTab('Overview')}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-md transition-all",
                activeTab === 'Overview' ? "bg-emerald-500/10 text-emerald-500" : "text-[#888] hover:bg-[#222] hover:text-white"
              )}
            >
              <Activity size={18} />
              {isSidebarOpen && <span className="text-xs font-mono">Overview</span>}
            </button>
            <button 
              onClick={() => setActiveTab('Registry')}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-md mt-1 transition-all",
                activeTab === 'Registry' ? "bg-emerald-500/10 text-emerald-500" : "text-[#888] hover:bg-[#222] hover:text-white"
              )}
            >
              <Layers size={18} />
              {isSidebarOpen && <span className="text-xs font-mono">Service Registry</span>}
            </button>
          </div>

          <div className="px-4">
            <div className={cn("text-[10px] font-mono uppercase tracking-widest text-[#444] mb-2", !isSidebarOpen && "hidden")}>Domains</div>
            {DOMAINS.map(domain => (
              <button 
                key={domain}
                onClick={() => setActiveTab(domain)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2 rounded-md mt-1 transition-all",
                  activeTab === domain ? "bg-emerald-500/10 text-emerald-500" : "text-[#888] hover:bg-[#222] hover:text-white"
                )}
              >
                <DomainIcon domain={domain} size={18} />
                {isSidebarOpen && <span className="text-xs font-mono">{domain}</span>}
              </button>
            ))}
          </div>
        </nav>

        <div className="p-4 border-t border-[#333]">
          <button className="w-full flex items-center gap-3 px-3 py-2 text-[#888] hover:text-white transition-colors">
            <Settings size={18} />
            {isSidebarOpen && <span className="text-xs font-mono">System Config</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-[#333] bg-[#0a0a0a]/80 backdrop-blur-md flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <h2 className="text-sm font-mono font-bold uppercase tracking-widest text-[#888]">{activeTab}</h2>
            <div className="h-4 w-[1px] bg-[#333]" />
            <div className="flex items-center gap-2 text-[10px] font-mono text-[#666]">
              <Clock size={12} />
              <span>{new Date().toLocaleTimeString()} UTC</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1 bg-[#1a1a1a] border border-[#333] rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-mono text-emerald-500">SYSTEM ONLINE</span>
            </div>
            <button className="p-2 text-[#666] hover:text-white transition-colors">
              <Share2 size={16} />
            </button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-black font-bold text-xs">
              JD
            </div>
          </div>
        </header>

        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'Overview' && renderOverview()}
              {activeTab === 'Registry' && renderRegistry()}
              {DOMAINS.includes(activeTab as Domain) && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-2xl font-mono font-bold text-white">{activeTab} Management</h1>
                      <p className="text-xs font-mono text-[#666] mt-1">Domain-specific microservices and process analytics for {activeTab}.</p>
                    </div>
                    <button className="px-4 py-2 bg-emerald-500 text-black font-mono text-xs font-bold rounded hover:bg-emerald-400 transition-colors">
                      PROVISION NEW SERVICE
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <MetricCard title="Domain Health" value="99.4" unit="%" icon={CheckCircle2} />
                    <MetricCard title="Active Instances" value={services.filter(s => s.domain === activeTab).length} unit="SVC" icon={Layers} />
                    <MetricCard title="Avg Latency" value="12" unit="ms" icon={Zap} />
                  </div>

                  <div className="bg-[#1a1a1a] border border-[#333] p-8 rounded-lg text-center">
                    <div className="w-16 h-16 bg-[#222] rounded-full flex items-center justify-center mx-auto mb-4 text-[#444]">
                      <DomainIcon domain={activeTab as Domain} size={32} />
                    </div>
                    <h3 className="text-sm font-mono text-white mb-2">No active process alerts for {activeTab}</h3>
                    <p className="text-xs font-mono text-[#666] max-w-md mx-auto">
                      All {services.filter(s => s.domain === activeTab).length} microservices in this domain are operating within normal parameters.
                    </p>
                  </div>

                  <div className="bg-[#1a1a1a] border border-[#333] rounded-lg overflow-hidden">
                    <div className="p-4 border-b border-[#333] flex justify-between items-center">
                      <h3 className="text-sm font-mono uppercase tracking-widest text-[#888]">Domain Services</h3>
                    </div>
                    <div className="divide-y divide-[#333]">
                      {services.filter(s => s.domain === activeTab).slice(0, 10).map(s => (
                        <div key={s.id} className="p-4 flex items-center justify-between hover:bg-[#222] transition-colors">
                          <div className="flex items-center gap-4">
                            <div className="text-xs font-mono text-white">{s.name}</div>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 bg-[#333] text-[#888] rounded">{s.language}</span>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-[10px] font-mono text-[#666]">{s.uptime}</div>
                            <StatusBadge status={s.status} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Footer */}
        <footer className="h-10 border-t border-[#333] bg-[#0a0a0a] flex items-center justify-between px-8 text-[10px] font-mono text-[#444]">
          <div className="flex gap-6">
            <span>NETWORK: STABLE</span>
            <span>NODES: 1024/1024</span>
            <span>REGION: ASIA-SOUTH-1</span>
          </div>
          <div className="flex gap-4">
            <span className="text-emerald-500/50">© 2026 TFMS GLOBAL ARCHITECTURE</span>
            <span className="hover:text-[#888] cursor-pointer">DOCUMENTATION</span>
            <span className="hover:text-[#888] cursor-pointer">SUPPORT</span>
          </div>
        </footer>
      </main>

      {/* Notification Stack */}
      <div className="fixed bottom-12 right-8 z-[100] flex flex-col gap-3 pointer-events-none">
        <AnimatePresence>
          {alerts.map(alert => (
            <div key={alert.id} className="pointer-events-auto">
              <AlertNotification alert={alert} onDismiss={dismissAlert} />
            </div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
