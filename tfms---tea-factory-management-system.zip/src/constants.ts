import { Microservice, Domain } from './types';

export const DOMAINS: Domain[] = [
  'Agriculture', 'Processing', 'QA', 'Inventory', 'Planning', 
  'SupplyChain', 'Sales', 'HR', 'Maintenance', 'Finance', 
  'Analytics', 'Integration'
];

const LANGUAGES = ['Go', 'Rust', 'Python', 'Java', 'Kotlin', 'C++', 'Node.js', 'Scala', 'Zig', 'C#'];

export const generateMicroservices = (count: number): Microservice[] => {
  return Array.from({ length: count }, (_, i) => {
    const domain = DOMAINS[Math.floor(Math.random() * DOMAINS.length)];
    const language = LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)];
    const status: Microservice['status'] = Math.random() > 0.95 ? (Math.random() > 0.5 ? 'failed' : 'degraded') : 'healthy';
    
    return {
      id: `svc-${i.toString().padStart(4, '0')}`,
      name: `${domain.toLowerCase()}-${language.toLowerCase()}-${i}`,
      domain,
      language,
      status,
      uptime: `${Math.floor(Math.random() * 99)}d ${Math.floor(Math.random() * 23)}h`,
      cpu: Math.floor(Math.random() * 100),
      memory: Math.floor(Math.random() * 1024),
    };
  });
};

export const generateSensorData = (points: number) => {
  return Array.from({ length: points }, (_, i) => ({
    timestamp: new Date(Date.now() - (points - i) * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    temperature: 20 + Math.random() * 10,
    humidity: 40 + Math.random() * 20,
    vibration: Math.random() * 5,
  }));
};
