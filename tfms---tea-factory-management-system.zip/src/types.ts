export type ServiceStatus = 'healthy' | 'degraded' | 'failed' | 'starting';

export interface Microservice {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: ServiceStatus;
  uptime: string;
  cpu: number;
  memory: number;
}

export interface SensorData {
  timestamp: string;
  temperature: number;
  humidity: number;
  vibration?: number;
}

export interface Alert {
  id: string;
  serviceId: string;
  serviceName: string;
  domain: string;
  status: 'failed' | 'degraded';
  timestamp: string;
  message: string;
}

export type Domain = 
  | 'Agriculture' 
  | 'Processing' 
  | 'QA' 
  | 'Inventory' 
  | 'Planning' 
  | 'SupplyChain' 
  | 'Sales' 
  | 'HR' 
  | 'Maintenance' 
  | 'Finance' 
  | 'Analytics' 
  | 'Integration';
